from telethon import TelegramClient, events
from zeus.tiktok import Online
import time
tiktok = Online()
@events.register(events.NewMessage)
async def tiktokhandler(event):
	        if ".tt" in event.raw_text:
	        	time.sleep(0.3)
	        	for d in tiktok.online:
	        		time.sleep(0.3)
	        		await event.edit(d)